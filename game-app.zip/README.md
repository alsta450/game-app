GitHub Action "main.yaml" for building the Jar and Docker Image and Pushing to the Registry
